DinoCraft Creative Update 1.3
Upload index.html to your existing DINO-CRAFT GitHub repository, replacing its current index.html.

NEW:
/creative (Creative + flight + invincibility)
/survival
/fly [on|off]
/god [on|off]
/give diamond_sword 1
/give @s golden_apple 16
/give all  (starter collection; inventory capacity is limited)
/items (browse every item supported by the game)
/spawn rex
/heal
/clear
/speed 1.5

KEYS:
/ opens command console
I opens creative catalog; click an item to equip it in your selected hotbar slot
G switches Creative/Survival
Space ascend when flying, Shift descend while flying
X drops one held item
Q dash
V shockwave REMOVED

Note: This is a beta build. JavaScript syntax tested; full gameplay/browser testing and bug-free behavior are not guaranteed.
